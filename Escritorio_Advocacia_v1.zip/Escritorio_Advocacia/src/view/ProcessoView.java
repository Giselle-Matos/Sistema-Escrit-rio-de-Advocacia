
package view;

import java.awt.Color;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.io.Serializable;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.swing.BoxLayout;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

import controller.AdvogadoController;
import controller.ClienteController;
import controller.MainController;
import controller.PessoaController;
import controller.ProcessoController;
import controller.TribunalController;
import exceptions.CnpjInvalidoException;
import exceptions.PessoaException;
import model.Advogado;
import model.Audiencia;
import model.Cliente;
import model.Conta;
import model.EFaseProcesso;
import model.Pessoa;
import model.Processo;
import model.Tribunal;
import util.IsValidCNPJ;
import util.IsValidCPF;
import util.IsValidDate;
import util.gerarNumeroProcesso;

public class ProcessoView extends JPanel implements Serializable {

	private static final long serialVersionUID = 1L;
	private JTextField textDataAbertura;
	private JTextField textDataConclusao;
	private JComboBox<EFaseProcesso> comboBoxFase;
	private JTextField textCPFouCNPJParteContraria;
	private JTextField textCliente;
	private JTextField textTribunal;
	private JTextArea textAreaAudiencias;

	private JButton salvarButton;
	private JButton listarButton;
	private JButton buscarProcessosButton;
	private JLabel mensagemErroLabel;

	private JRadioButton cpfParteContrariaRadioButton;
	private JRadioButton cnpjParteContrariaRadioButton;

	private JRadioButton cpfClienteRadioButton;
	private JRadioButton cnpjClienteRadioButton;

	public ProcessoView() {
		setLayout(new GridBagLayout());
		GridBagConstraints gbc = new GridBagConstraints();
		gbc.insets = new Insets(10, 10, 10, 10);
		gbc.fill = GridBagConstraints.HORIZONTAL;
		gbc.anchor = GridBagConstraints.NORTHWEST;

		// Data de Abertura
		gbc.gridx = 0;
		gbc.gridy = 1;
		add(new JLabel("Data de Abertura (yyyy-MM-dd):"), gbc);
		textDataAbertura = new JTextField(20);
		gbc.gridx = 1;
		add(textDataAbertura, gbc);

		// Data de Conclusão
		gbc.gridx = 0;
		gbc.gridy = 2;
		add(new JLabel("Data de Conclusão (yyyy-MM-dd, ou deixe em branco):"), gbc);
		textDataConclusao = new JTextField(20);
		gbc.gridx = 1;
		add(textDataConclusao, gbc);

		// Fase do Processo
		gbc.gridx = 0;
		gbc.gridy = 3;
		add(new JLabel("Fase do Processo:"), gbc);
		comboBoxFase = new JComboBox<>(EFaseProcesso.values());
		gbc.gridx = 1;
		add(comboBoxFase, gbc);

		// RadioButtons para CPF e CNPJ Parte Contrária
		JPanel panelTipoDocumentoParteContraria = new JPanel();
		cpfParteContrariaRadioButton = new JRadioButton("CPF");
		cnpjParteContrariaRadioButton = new JRadioButton("CNPJ");
		ButtonGroup groupParteContraria = new ButtonGroup();
		groupParteContraria.add(cpfParteContrariaRadioButton);
		groupParteContraria.add(cnpjParteContrariaRadioButton);
		panelTipoDocumentoParteContraria.add(new JLabel("Tipo de Documento Parte Contrária:"));
		panelTipoDocumentoParteContraria.add(cpfParteContrariaRadioButton);
		panelTipoDocumentoParteContraria.add(cnpjParteContrariaRadioButton);
		gbc.gridx = 0;
		gbc.gridy = 4;
		gbc.gridwidth = 2;
		add(panelTipoDocumentoParteContraria, gbc);

		// Campo para CPF/CNPJ da Parte Contrária
		gbc.gridy = 5;
		add(new JLabel("CPF/CNPJ da Parte Contrária:"), gbc);
		textCPFouCNPJParteContraria = new JTextField(20);
		gbc.gridx = 1;
		add(textCPFouCNPJParteContraria, gbc);

		// RadioButtons para CPF e CNPJ Cliente
		JPanel panelTipoDocumentoCliente = new JPanel();
		cpfClienteRadioButton = new JRadioButton("CPF");
		cnpjClienteRadioButton = new JRadioButton("CNPJ");
		ButtonGroup groupCliente = new ButtonGroup();
		groupCliente.add(cpfClienteRadioButton);
		groupCliente.add(cnpjClienteRadioButton);
		panelTipoDocumentoCliente.add(new JLabel("Tipo de Documento Cliente:"));
		panelTipoDocumentoCliente.add(cpfClienteRadioButton);
		panelTipoDocumentoCliente.add(cnpjClienteRadioButton);
		gbc.gridx = 0;
		gbc.gridy = 6;
		gbc.gridwidth = 2;
		add(panelTipoDocumentoCliente, gbc);

		// Campo para CPF/CNPJ do Cliente
		gbc.gridy = 7;
		add(new JLabel("Cliente (CPF/CNPJ):"), gbc);
		textCliente = new JTextField(20);
		gbc.gridx = 1;
		add(textCliente, gbc);

		// Tribunal
		gbc.gridx = 0;
		gbc.gridy = 8;
		add(new JLabel("Tribunal:"), gbc);
		textTribunal = new JTextField(20);
		gbc.gridx = 1;
		add(textTribunal, gbc);

		// Audiências
		gbc.gridx = 0;
		gbc.gridy = 9;
		add(new JLabel("Audiências (detalhes):"), gbc);
		textAreaAudiencias = new JTextArea(10, 40);
		gbc.gridx = 1;
		add(new JScrollPane(textAreaAudiencias), gbc);

		// Mensagem de Erro
		mensagemErroLabel = new JLabel("");
		mensagemErroLabel.setForeground(Color.RED);
		gbc.gridx = 0;
		gbc.gridy = 10;
		gbc.gridwidth = 2;
		add(mensagemErroLabel, gbc);

		// Botão Salvar
		salvarButton = new JButton("Salvar");
		gbc.gridx = 0;
		gbc.gridy = 11;
		gbc.gridwidth = 2;
		gbc.anchor = GridBagConstraints.CENTER;
		add(salvarButton, gbc);

		// Botão Listar
		listarButton = new JButton("Listar Processos");
		gbc.gridx = 0;
		gbc.gridy = 12;
		add(listarButton, gbc);

		// Botão Buscar Processos
		buscarProcessosButton = new JButton("Buscar Processos");
		gbc.gridx = 0;
		gbc.gridy = 13;
		add(buscarProcessosButton, gbc);

		// Ações dos botões
		salvarButton.addActionListener(e -> actionSalvar());
		listarButton.addActionListener(e -> {
			try {
				actionListar();
			} catch (PessoaException ex) {
				// Registra a exceção com uma mensagem descritiva
				Logger.getLogger(getClass().getName()).log(Level.SEVERE, "Falha ao listar itens", ex);

				// Exibe uma mensagem de erro amigável para o usuário
				JOptionPane.showMessageDialog(null,
						"Ocorreu um erro ao listar os itens. Por favor, tente novamente mais tarde.", "Erro",
						JOptionPane.ERROR_MESSAGE);
			}
		});

		buscarProcessosButton.addActionListener(e -> actionBuscarProcessosPorNumero());

	}

	private void actionSalvar() {
		ProcessoController processoController = MainController.getProcessoController();
		ClienteController clienteController = MainController.getClienteController();
		PessoaController pessoaController = MainController.getPessoaController();
		TribunalController tribunalController = MainController.getTribunalController();

		String registroParteContraria = textCPFouCNPJParteContraria.getText().trim();
		String registroCliente = textCliente.getText().trim();
		boolean isCPFParteContraria = cpfParteContrariaRadioButton.isSelected();
		boolean isCPFCliente = cpfClienteRadioButton.isSelected();

		Pessoa pessoaParteContraria = null;
		Cliente cliente = null;

		try {
			// Validação Parte Contrária
			if (isCPFParteContraria) {
				if (IsValidCPF.isValid(registroParteContraria)) {
					System.out.println("\n\nO CPF DA PARTE CONTRARIA É VALIDO\nCRIANDO PARTE CONTRARIA...");

				}
			} else if (!IsValidCNPJ.isValid(registroParteContraria)) {
				throw new CnpjInvalidoException();
			}

			pessoaParteContraria = pessoaController.buscarParteContraria(registroParteContraria, isCPFParteContraria);

			if (pessoaParteContraria == null) {
				JOptionPane.showMessageDialog(this, "Parte contrária com CPF/CNPJ não encontrada.");
				return;
			}

			// Validação Cliente
			if (isCPFCliente) {
				if (IsValidCPF.isValid(registroCliente)) {
					System.out.println("IsValidCPF.isValid(registroCliente):");

					System.out.println(IsValidCPF.isValid(registroCliente));

				}
			} else if (!IsValidCNPJ.isValid(registroCliente)) {

				throw new CnpjInvalidoException();
			}

			cliente = clienteController.buscarClientePorCpfOuCnpj(registroCliente, isCPFCliente);

			if (cliente == null) {
				int resposta = JOptionPane.showConfirmDialog(this,
						"Cliente com CPF/CNPJ não encontrado. Deseja cadastrar uma nova pessoa?", "Cadastro",
						JOptionPane.YES_NO_OPTION);
				if (resposta == JOptionPane.YES_OPTION) {
					navegarParaCadastroPessoa(registroCliente); // Assumes this method exists
					return;
				} else {
					JOptionPane.showMessageDialog(this, "Operação cancelada.");
					return;
				}
			}

			// Definir e inicializar as variáveis para ProcessoDTO
			long numero = gerarNumeroProcesso.gerarNumeroProcessoUnico(); // Assumes this method exists
			Date dataAbertura = new SimpleDateFormat("yyyy-MM-dd").parse(textDataAbertura.getText());
			Date dataConclusao = textDataConclusao.getText().isEmpty() ? null
					: new SimpleDateFormat("yyyy-MM-dd").parse(textDataConclusao.getText());

			IsValidDate dateValidator = new IsValidDate();

			if (!dateValidator.isValid(dataAbertura)) {
				throw new IllegalArgumentException("Data de abertura inválida.");
			}

			if (dataConclusao != null && !dateValidator.isValid(dataConclusao)) {
				throw new IllegalArgumentException("Data de conclusão inválida.");
			}

			String siglaTribunal = textTribunal.getText();
			Tribunal tribunal = tribunalController.buscarTribunalPorSigla(siglaTribunal);
			if (tribunal == null) {
				JOptionPane.showMessageDialog(this, "Tribunal com sigla " + siglaTribunal + " não encontrado.");
				return;
			}

			Conta conta = new Conta();

			// Criar e adicionar o ProcessoDTO
			Processo processo = new Processo(numero, dataAbertura, pessoaParteContraria, tribunal, conta, cliente);
			processoController.addProcesso(processo);
			JOptionPane.showMessageDialog(this, "Processo adicionado com sucesso.");

			limparForm();

		} catch (Exception e) {
			e.printStackTrace();
			JOptionPane.showMessageDialog(this, "Erro ao salvar o processo: " + e.getMessage());
		}
	}

	private void actionListar() throws PessoaException {
		ProcessoController processoController = MainController.getProcessoController(); // Obtém o controlador
		List<Processo> processos = processoController.getProcessos();

		textAreaAudiencias.setText(""); // Limpa o texto anterior

		if (processos.isEmpty()) {
			textAreaAudiencias.append("Nenhum processo encontrado.\n");
		} else {
			for (Processo p : processos) {
				textAreaAudiencias.append(String.format("Processo %d\n", p.getNumero()));
				textAreaAudiencias.append(String.format("Data de Abertura: %s\n", p.getDataAbertura()));
				textAreaAudiencias.append(String.format("Parte Contrária: %s\n", p.getParteContraria()));
				textAreaAudiencias.append(String.format("Tribunal: %s\n", p.getTribunal()));
				textAreaAudiencias.append(String.format("Conta: %s\n", p.getConta()));
				textAreaAudiencias.append(String.format("Cliente: %s\n", p.getCliente()));
				textAreaAudiencias.append("-----\n");
			}
		}
	}

	private void limparForm() {
		textDataAbertura.setText("");
		textDataConclusao.setText("");
		comboBoxFase.setSelectedIndex(0);
		textCPFouCNPJParteContraria.setText("");
		textCliente.setText("");
		textTribunal.setText("");
		textAreaAudiencias.setText("");
	}

	private void navegarParaCadastroPessoa(String cpfOuCnpj) {
		PessoaView cadastroPessoaView = new PessoaView();
		cadastroPessoaView.setVisible(true);
	}

	private void actionBuscarProcessosPorNumero() {
		JTextField inputField = new JTextField(20);
		JPanel panel = new JPanel();
		panel.add(new JLabel("Digite o número do processo:"));
		panel.add(inputField);

		int result = JOptionPane.showConfirmDialog(this, panel, "Buscar Processos por Número",
				JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);

		if (result == JOptionPane.OK_OPTION) {
			String numeroProcessoStr = inputField.getText().trim();

			try {
				long numeroProcesso = Long.parseLong(numeroProcessoStr);
				ProcessoController processoController = MainController.getProcessoController();
				Processo processo = processoController.findProcessoByNumero(numeroProcesso);

				if (processo != null) {
					exibirDetalhesProcesso(processo);
				} else {
					JOptionPane.showMessageDialog(this, "Processo não encontrado.");
				}
			} catch (NumberFormatException e) {
				JOptionPane.showMessageDialog(this, "Número do processo inválido.");
			} catch (Exception e) {
				JOptionPane.showMessageDialog(this, "Erro inesperado: " + e.getMessage());
			}
		}
	}

	private void exibirDetalhesProcesso(Processo processo) {
		// Criação da nova janela
		JFrame detalhesFrame = new JFrame("Detalhes do Processo Nº " + processo.getNumero());
		detalhesFrame.setSize(600, 400); // Defina o tamanho conforme necessário
		detalhesFrame.setLocationRelativeTo(null);
		detalhesFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

		JPanel panel = new JPanel();
		panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));

		// Adicionar detalhes do processo
		panel.add(new JLabel("Número do Processo: " + processo.getNumero()));
		panel.add(new JLabel("Data de Abertura: " + processo.getDataAbertura()));
		panel.add(new JLabel("Data de Conclusão: "
				+ (processo.getDataConclusao() != null ? processo.getDataConclusao() : "Não Concluído")));
		panel.add(new JLabel("Fase: " + processo.getFase()));
		panel.add(new JLabel("Parte Contrária: " + processo.getParteContraria().getNome()));
		panel.add(new JLabel("Tribunal: " + processo.getTribunal().getSigla()));
		panel.add(new JLabel("Cliente: " + processo.getCliente().getPessoa().getNome()));

		// Adicionar audiências
		JTextArea audienciasArea = new JTextArea(10, 50);
		audienciasArea.setEditable(false);
		atualizarAudienciasTextArea(audienciasArea, processo);
		panel.add(new JScrollPane(audienciasArea));

		// Botão para adicionar audiência
		JButton addAudiênciaButton = new JButton("Adicionar Audiência");
		addAudiênciaButton.addActionListener(e -> abrirDialogoAdicionarAudiência(processo, audienciasArea));
		panel.add(addAudiênciaButton);

		detalhesFrame.add(panel);
		detalhesFrame.setVisible(true);
	}

	private void atualizarAudienciasTextArea(JTextArea audienciasArea, Processo processo) {
		StringBuilder audienciasText = new StringBuilder("Audiências:\n");
		for (Audiencia audiencia : processo.getAudiencias()) {
			audienciasText.append("Data: ").append(audiencia.getData()).append(", Recomendação: ")
					.append(audiencia.getRecomendacao()).append("\n");
		}
		audienciasArea.setText(audienciasText.toString());
	}

	private void abrirDialogoAdicionarAudiência(Processo processo, JTextArea audienciasArea) {
		JDialog dialog = new JDialog((JFrame) null, "Adicionar Audiência", true);
		dialog.setSize(300, 250);
		dialog.setLocationRelativeTo(null);
		dialog.setLayout(new BoxLayout(dialog.getContentPane(), BoxLayout.Y_AXIS));

		JTextField dataField = new JTextField();
		JTextField recomendacaoField = new JTextField();
		JTextField processoField = new JTextField();
		JTextField advogadoField = new JTextField();

		dialog.add(new JLabel("Data da Audiência (dd/MM/yyyy):"));
		dialog.add(dataField);
		dialog.add(new JLabel("Recomendação:"));
		dialog.add(recomendacaoField);
		dialog.add(new JLabel("Número do Processo:"));
		dialog.add(processoField);
		dialog.add(new JLabel("Advogado (registro):"));
		dialog.add(advogadoField);

		JButton addButton = new JButton("Adicionar");
		addButton.addActionListener(e -> {
			try {
				String dataStr = dataField.getText().trim();
				if (dataStr.isEmpty() || !IsValidDate.isValid(dataStr)) {
					JOptionPane.showMessageDialog(dialog, "Data inválida. Use o formato dd/MM/yyyy.", "Erro",
							JOptionPane.ERROR_MESSAGE);
					return;
				}

				// Conversão da string para Date
				SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
				Date data = dateFormat.parse(dataStr);

				String recomendacao = recomendacaoField.getText().trim();
				if (recomendacao.isEmpty()) {
					JOptionPane.showMessageDialog(dialog, "Todos os campos devem ser preenchidos.", "Erro",
							JOptionPane.ERROR_MESSAGE);
					return;
				}

				String numeroProcessoStr = processoField.getText().trim();
				long numeroProcessoLong = Long.parseLong(numeroProcessoStr);
				ProcessoController processoController = MainController.getProcessoController();
				Processo processoF = processoController.findProcessoByNumero(numeroProcessoLong);

				String registroAdvogado = advogadoField.getText().trim();
				AdvogadoController advogadoController = MainController.getAdvogadoController();
				Advogado advogado = advogadoController.buscarAdvogadoPorRegistro(registroAdvogado); // Buscando advogado
																									// pelo registro

				if (processoF == null || advogado == null) {
					JOptionPane.showMessageDialog(dialog, "Processo ou advogado não encontrado.", "Erro",
							JOptionPane.ERROR_MESSAGE);
					return;
				}

				// Criação da nova audiência
				Audiencia novaAudiência = new Audiencia(data, recomendacao, processoF, advogado);
				processoF.addAudiencia(novaAudiência); // Adiciona a audiência ao processo
				atualizarAudienciasTextArea(audienciasArea, processoF);
				dialog.dispose();
			} catch (ParseException ex) {
				JOptionPane.showMessageDialog(dialog, "Formato de data inválido. Use o formato dd/MM/yyyy.", "Erro",
						JOptionPane.ERROR_MESSAGE);
			} catch (Exception ex) {
				JOptionPane.showMessageDialog(dialog, "Erro ao adicionar audiência: " + ex.getMessage(), "Erro",
						JOptionPane.ERROR_MESSAGE);
			}
		});

		dialog.add(addButton);
		dialog.setVisible(true);
	}
}
