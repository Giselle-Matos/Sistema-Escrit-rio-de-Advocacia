package view;

import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.io.Serializable;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

import controller.MainController;
import controller.TribunalController;
import exceptions.TribunalException;
import model.Tribunal;

public class TribunalView extends JPanel implements Serializable {

	private static final long serialVersionUID = 1L;

	private JTextField textSigla;
	private JTextArea textDescricao;
	private JTextField textSecao;
	private JTextArea textArea; // Para exibir a lista de tribunais
	private JButton salvarButton;
	private JButton listarButton; // Botão para listar
	private JLabel mensagemErroLabel;

	public TribunalView() {
		setLayout(new GridBagLayout());
		GridBagConstraints gbc = new GridBagConstraints();
		gbc.insets = new Insets(10, 10, 10, 10);
		gbc.fill = GridBagConstraints.HORIZONTAL;
		gbc.anchor = GridBagConstraints.NORTHWEST;

		// Sigla do Tribunal
		gbc.gridx = 0;
		gbc.gridy = 1;
		gbc.weightx = 0.2;
		add(new JLabel("Sigla do Tribunal:"), gbc);

		textSigla = new JTextField(20);
		gbc.gridx = 1;
		gbc.weightx = 0.8;
		add(textSigla, gbc);

		// Descrição do Tribunal
		gbc.gridx = 0;
		gbc.gridy = 3;
		gbc.weightx = 0.2;
		add(new JLabel("Descrição do Tribunal:"), gbc);

		textDescricao = new JTextArea(5, 20);
		textDescricao.setLineWrap(true);
		textDescricao.setWrapStyleWord(true);
		gbc.gridx = 1;
		gbc.weightx = 0.8;
		gbc.fill = GridBagConstraints.BOTH;
		gbc.weighty = 0.3;
		add(new JScrollPane(textDescricao), gbc);

		// Seção do Tribunal
		gbc.gridx = 0;
		gbc.gridy = 4;
		add(new JLabel("Seção do Tribunal:"), gbc);

		textSecao = new JTextField(20);
		gbc.gridx = 1;
		add(textSecao, gbc);

		// Mensagem de Erro
		mensagemErroLabel = new JLabel("");
		mensagemErroLabel.setForeground(java.awt.Color.RED);
		gbc.gridx = 0;
		gbc.gridy = 5;
		gbc.gridwidth = 2;
		add(mensagemErroLabel, gbc);

		// Área de texto para exibir a lista de tribunais
		gbc.gridx = 0;
		gbc.gridy = 6;
		gbc.gridwidth = 2;
		gbc.fill = GridBagConstraints.BOTH;
		gbc.weightx = 1;
		gbc.weighty = 0.5;
		textArea = new JTextArea(10, 30);
		textArea.setEditable(false);
		add(new JScrollPane(textArea), gbc);

		// Botão Salvar
		salvarButton = new JButton("Salvar");
		gbc.gridx = 0;
		gbc.gridy = 7;
		gbc.gridwidth = 2;
		gbc.anchor = GridBagConstraints.CENTER;
		add(salvarButton, gbc);

		// Botão Listar
		listarButton = new JButton("Listar Tribunais");
		gbc.gridx = 0;
		gbc.gridy = 8;
		add(listarButton, gbc);

		// Ações dos botões
		listarButton.addActionListener(e -> {
			try {
				actionListar();
				JOptionPane.showMessageDialog(this, "Listagem concluída com sucesso!", "Sucesso",
						JOptionPane.INFORMATION_MESSAGE);
			} catch (TribunalException ex) {
				JOptionPane.showMessageDialog(this, "Erro ao listar: " + ex.getMessage(), "Erro",
						JOptionPane.ERROR_MESSAGE);
				ex.printStackTrace(); // Loga o erro para depuração
			} catch (Exception ex) {
				// Captura qualquer outra exceção não prevista
				JOptionPane.showMessageDialog(this, "Erro inesperado: " + ex.getMessage(), "Erro",
						JOptionPane.ERROR_MESSAGE);
				ex.printStackTrace(); // Loga o erro para depuração
			}
		});

		salvarButton.addActionListener(e -> {
			try {
				actionSalvar();
				JOptionPane.showMessageDialog(this, "Dados salvos com sucesso!", "Sucesso",
						JOptionPane.INFORMATION_MESSAGE);
			} catch (TribunalException ex) {
				JOptionPane.showMessageDialog(this, "Erro ao salvar: " + ex.getMessage(), "Erro",
						JOptionPane.ERROR_MESSAGE);
				ex.printStackTrace(); // Loga o erro para depuração
			} catch (Exception ex) {
				// Captura qualquer outra exceção não prevista
				JOptionPane.showMessageDialog(this, "Erro inesperado: " + ex.getMessage(), "Erro",
						JOptionPane.ERROR_MESSAGE);
				ex.printStackTrace(); // Loga o erro para depuração
			}
		});
	}

	public void actionSalvar() throws TribunalException {

		TribunalController tribunalController = MainController.getTribunalController();

		String sigla = textSigla.getText();
		String descricao = textDescricao.getText();
		String secao = textSecao.getText();

		Tribunal tribunal = new Tribunal(sigla, descricao, secao);

		try {
			tribunalController.addTribunal(tribunal);
			JOptionPane.showMessageDialog(this, "Tribunal gravado com sucesso");
			limparForm();
		} catch (TribunalException e) {
			// Exibe a mensagem de erro em um JOptionPane
			JOptionPane.showMessageDialog(this, e.getMessage());
			mensagemErroLabel.setText(e.getMessage()); // Mostra a mensagem de erro no JLabel
		}
	}

	public void actionListar() throws TribunalException {
		TribunalController tribunalController = MainController.getTribunalController();

		List<Tribunal> lista = tribunalController.getTribunais();
		textArea.setText("");

		for (Tribunal t : lista) {
			textArea.append(String.format("%s - %s (seção: %s)\n", t.getSigla(), t.getDescricao(), t.getSecao()));
		}
	}

	public void limparForm() {
		textSigla.setText("");
		textDescricao.setText("");
		textSecao.setText("");
	}
}
