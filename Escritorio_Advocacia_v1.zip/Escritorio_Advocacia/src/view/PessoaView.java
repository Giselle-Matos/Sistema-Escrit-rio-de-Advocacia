package view;

import java.awt.Color;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.io.Serializable;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

import controller.MainController;
import controller.PessoaController;
import exceptions.PessoaException;
import exceptions.TelefoneInvalidoException;
import model.Advogado;
import model.Pessoa;
import model.PessoaFisica;
import model.PessoaJuridica;
import util.IsTelefoneValid; // Importando a classe de validação de telefone

public class PessoaView extends JPanel implements Serializable {

	private static final long serialVersionUID = 1L;

	private JComboBox<String> tipoPessoaComboBox;
	private JTextField textNome;
	private JTextField textEmail;
	private JTextField textTelefone;
	private JTextField textCPF; // Campo para CPF
	private JTextField textCNPJ; // Campo para CNPJ
	private JTextField textRegistroAdvogado; // Campo para registro de advogado (se necessário)
	private JTextField textPreposto; // Campo para preposto (se necessário)
	private JTextArea textArea; // Para exibir a lista de pessoas
	private JButton salvarButton;
	private JButton listarButton;
	private JLabel mensagemErroLabel;

	public PessoaView() {
		setLayout(new GridBagLayout());
		GridBagConstraints gbc = new GridBagConstraints();
		gbc.insets = new Insets(10, 10, 10, 10);
		gbc.fill = GridBagConstraints.HORIZONTAL;
		gbc.anchor = GridBagConstraints.NORTHWEST;

		// Selecionar tipo de pessoa
		gbc.gridx = 0;
		gbc.gridy = 0;
		gbc.weightx = 0.2;
		add(new JLabel("Tipo de Pessoa:"), gbc);

		tipoPessoaComboBox = new JComboBox<>(new String[] { "Pessoa Física", "Pessoa Jurídica", "Advogado" });
		gbc.gridx = 1;
		gbc.weightx = 0.8;
		add(tipoPessoaComboBox, gbc);

		// Nome da Pessoa
		gbc.gridx = 0;
		gbc.gridy = 1;
		add(new JLabel("Nome:"), gbc);

		textNome = new JTextField(20);
		gbc.gridx = 1;
		add(textNome, gbc);

		// Email da Pessoa
		gbc.gridx = 0;
		gbc.gridy = 2;
		add(new JLabel("Email:"), gbc);

		textEmail = new JTextField(20);
		gbc.gridx = 1;
		add(textEmail, gbc);

		// Telefone da Pessoa
		gbc.gridx = 0;
		gbc.gridy = 3;
		add(new JLabel("Telefone (ex: (xx) xxxxx-xxxx): "), gbc);

		textTelefone = new JTextField(20);
		gbc.gridx = 1;
		add(textTelefone, gbc);

		// CPF
		gbc.gridx = 0;
		gbc.gridy = 4;
		add(new JLabel("CPF:"), gbc);

		textCPF = new JTextField(20);
		gbc.gridx = 1;
		add(textCPF, gbc);

		// CNPJ
		gbc.gridx = 0;
		gbc.gridy = 5;
		add(new JLabel("CNPJ:"), gbc);

		textCNPJ = new JTextField(20);
		gbc.gridx = 1;
		add(textCNPJ, gbc);

		// Registro do Advogado (somente para advogados)
		gbc.gridx = 0;
		gbc.gridy = 6;
		add(new JLabel("Registro do Advogado:"), gbc);

		textRegistroAdvogado = new JTextField(20);
		gbc.gridx = 1;
		add(textRegistroAdvogado, gbc);

		// Preposto (somente para pessoa jurídica)
		gbc.gridx = 0;
		gbc.gridy = 7;
		add(new JLabel("Preposto:"), gbc);

		textPreposto = new JTextField(20);
		gbc.gridx = 1;
		add(textPreposto, gbc);

		// Mensagem de Erro
		mensagemErroLabel = new JLabel("");
		mensagemErroLabel.setForeground(Color.RED);
		gbc.gridx = 0;
		gbc.gridy = 8;
		gbc.gridwidth = 2;
		add(mensagemErroLabel, gbc);

		// Área de texto para exibir a lista de pessoas
		gbc.gridx = 0;
		gbc.gridy = 9;
		gbc.gridwidth = 2;
		gbc.fill = GridBagConstraints.BOTH;
		gbc.weightx = 1;
		gbc.weighty = 0.5;
		textArea = new JTextArea(10, 30);
		textArea.setEditable(false);
		add(new JScrollPane(textArea), gbc);

		// Botão Salvar
		salvarButton = new JButton("Salvar");
		gbc.gridx = 0;
		gbc.gridy = 10;
		gbc.gridwidth = 2;
		gbc.anchor = GridBagConstraints.CENTER;
		add(salvarButton, gbc);

		// Botão Listar
		listarButton = new JButton("Listar Pessoas");
		gbc.gridx = 0;
		gbc.gridy = 11;
		add(listarButton, gbc);

		// Ações dos botões
		listarButton.addActionListener(e -> listarPessoas());
		salvarButton.addActionListener(e -> {
			try {
				actionSalvar();
				JOptionPane.showMessageDialog(this, "Dados salvos com sucesso!", "Sucesso",
						JOptionPane.INFORMATION_MESSAGE);
			} catch (TelefoneInvalidoException ex) {
				JOptionPane.showMessageDialog(this, "Número de telefone inválido: " + ex.getMessage(), "Erro",
						JOptionPane.ERROR_MESSAGE);
			} catch (PessoaException ex) {
				JOptionPane.showMessageDialog(this, "Erro com os dados da pessoa: " + ex.getMessage(), "Erro",
						JOptionPane.ERROR_MESSAGE);
			} catch (Exception ex) {
				// Captura qualquer outra exceção não prevista
				JOptionPane.showMessageDialog(this, "Erro inesperado: " + ex.getMessage(), "Erro",
						JOptionPane.ERROR_MESSAGE);
				ex.printStackTrace(); // Loga o erro para depuração
			}
		});

		// Alterações na interface baseadas no tipo de pessoa
		tipoPessoaComboBox.addActionListener(e -> toggleCamposAdicionais());
		toggleCamposAdicionais(); // Chama no início para definir os campos corretamente
	}

	// Método para alternar campos adicionais com base no tipo de pessoa selecionado
	private void toggleCamposAdicionais() {
		String tipoPessoa = (String) tipoPessoaComboBox.getSelectedItem();

		boolean isPessoaFisica = tipoPessoa.equals("Pessoa Física");
		boolean isJuridica = tipoPessoa.equals("Pessoa Jurídica");
		boolean isAdvogado = tipoPessoa.equals("Advogado");

		textCPF.setEnabled(isPessoaFisica || isAdvogado);
		textCNPJ.setEnabled(isJuridica);
		textRegistroAdvogado.setEnabled(isAdvogado);
		textPreposto.setEnabled(isJuridica);

		// Limpar campos que não são necessários
		if (!isPessoaFisica)
			textCPF.setText("");
		if (!isJuridica)
			textCNPJ.setText("");
		if (!isAdvogado)
			textRegistroAdvogado.setText("");
		if (!isJuridica)
			textPreposto.setText("");
	}

	public void actionSalvar() throws TelefoneInvalidoException, PessoaException {
		PessoaController pessoaController = MainController.getPessoaController();

		String tipoPessoa = (String) tipoPessoaComboBox.getSelectedItem();
		String nome = textNome.getText();
		String email = textEmail.getText();
		String telefone = textTelefone.getText();
		String cpf = textCPF.isEnabled() ? textCPF.getText() : null;
		String cnpj = textCNPJ.isEnabled() ? textCNPJ.getText() : null;
		String registroAdvogado = textRegistroAdvogado.isEnabled() ? textRegistroAdvogado.getText() : null;
		String prepostoCPF = textPreposto.isEnabled() ? textPreposto.getText() : null;

		// Validação do telefone
		if (!IsTelefoneValid.isValid(telefone)) {
			throw new TelefoneInvalidoException(telefone);
		}

		Pessoa pessoa = null;

		if ("Pessoa Física".equals(tipoPessoa)) {
			pessoa = new PessoaFisica(nome, cpf, email, telefone);
		} else if ("Pessoa Jurídica".equals(tipoPessoa)) {
			PessoaFisica preposto = pessoaController.getPrepostoByCPF(prepostoCPF);

			pessoa = new PessoaJuridica(nome, cnpj, preposto, email, telefone);
		} else if ("Advogado".equals(tipoPessoa)) {
			System.out.println("dentro de advogado1");
			pessoa = new Advogado(nome, email, telefone, cpf, registroAdvogado);
			System.out.println(pessoa);
		}

		if (pessoa != null) {
			try {
				pessoaController.addPessoa(pessoa, tipoPessoa);
				JOptionPane.showMessageDialog(this, "Pessoa gravada com sucesso");
				limparForm();
			} catch (PessoaException e) {
				JOptionPane.showMessageDialog(this, e.getMessage());
				mensagemErroLabel.setText(e.getMessage());
			}
		} else {
			JOptionPane.showMessageDialog(this, "Tipo de pessoa desconhecido.");
		}
		MainController.save();
	}

	public void listarPessoas() {
		PessoaController pessoaController = MainController.getPessoaController();
		StringBuilder sb = new StringBuilder();
		for (Pessoa p : pessoaController.getPessoas()) {
			if (p instanceof PessoaFisica) {
				PessoaFisica pessoaFisica = (PessoaFisica) p;
				sb.append(
						String.format("Pessoa Física - %s (email: %s, telefone: %s, CPF: %s)\n", pessoaFisica.getNome(),
								pessoaFisica.getEmail(), pessoaFisica.getTelefone(), pessoaFisica.getRegistroRF()));
			} else if (p instanceof PessoaJuridica) {
				PessoaJuridica pessoaJuridica = (PessoaJuridica) p;
				sb.append(String.format("Pessoa Jurídica - %s (email: %s, telefone: %s, CNPJ: %s, Preposto: %s)\n",
						pessoaJuridica.getNome(), pessoaJuridica.getEmail(), pessoaJuridica.getTelefone(),
						pessoaJuridica.getRegistroRF(),
						pessoaJuridica.getPreposto() != null ? pessoaJuridica.getPreposto().getNome() : "Nenhum"));
			} else if (p instanceof Advogado) {
				Advogado advogado = (Advogado) p;
				sb.append(String.format("Advogado - %s (email: %s, telefone: %s, CPF: %s, Registro: %s)\n",
						advogado.getNome(), advogado.getEmail(), advogado.getTelefone(), advogado.getRegistroRF(),
						advogado.getRegistro()));
			}
		}
		textArea.setText(sb.toString());
	}

	private void limparForm() {
		textNome.setText("");
		textEmail.setText("");
		textTelefone.setText("");
		textCPF.setText("");
		textCNPJ.setText("");
		textRegistroAdvogado.setText("");
		textPreposto.setText("");
	}
}
