package view;

import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Insets;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

import controller.ContaController;
import controller.DespesaController;
import controller.MainController;
import controller.PagamentoController;
import controller.ProcessoController;
import exceptions.ContaException;
import exceptions.PessoaException;
import exceptions.ProcessoNotFoundException;
import model.Conta;
import model.Despesa;
import model.EFormaPagamento;
import model.Pagamento;
import model.Processo;

public class ContaView extends JPanel {

	private static final long serialVersionUID = 1L;

	private JTextField textNumeroProcesso;
	private JTextField textDataPagamento;
	private JTextField textValorPagamento;
	private JTextField textFormaPagamento;
	private JTextField textDataDespesa;
	private JTextField textValorDespesa;
	private JTextField textDescricaoDespesa;
	private JTextArea textArea;
	private JButton listarDespesasButton;
	private JButton listarPagamentosButton;
	private JButton listarExtratoButton;
	private JButton adicionarPagamentoButton;
	private JButton adicionarDespesaButton;

	PagamentoController controllerPagamento = MainController.getPagamentoController();

	public ContaView() {

		System.out.println(MainController.getPagamentoController());

		setLayout(new GridBagLayout());
		GridBagConstraints gbc = new GridBagConstraints();
		gbc.insets = new Insets(10, 10, 10, 10);
		gbc.fill = GridBagConstraints.HORIZONTAL;
		gbc.anchor = GridBagConstraints.NORTHWEST;

		// Campo de texto para o número do processo
		textNumeroProcesso = new JTextField(15);
		gbc.gridx = 0;
		gbc.gridy = 0;
		gbc.gridwidth = 2;
		gbc.anchor = GridBagConstraints.WEST;
		add(new JLabel("Número do Processo:"), gbc);
		gbc.gridy = 1;
		add(textNumeroProcesso, gbc);

		// Configurar os botões
		listarDespesasButton = new JButton("Listar Despesas");
		listarPagamentosButton = new JButton("Listar Pagamentos");
		listarExtratoButton = new JButton("Listar Extrato Completo");
		adicionarPagamentoButton = new JButton("Adicionar Pagamento");
		adicionarDespesaButton = new JButton("Adicionar Despesa");

		gbc.gridy = 2;
		add(listarDespesasButton, gbc);
		gbc.gridy = 3;
		add(listarPagamentosButton, gbc);
		gbc.gridy = 4;
		add(listarExtratoButton, gbc);
		gbc.gridy = 5;
		add(adicionarPagamentoButton, gbc);
		gbc.gridy = 6;
		add(adicionarDespesaButton, gbc);

		// Área de texto para exibir informações
		gbc.gridy = 7;
		gbc.gridwidth = 2;
		gbc.fill = GridBagConstraints.BOTH;
		gbc.weightx = 1;
		gbc.weighty = 0.5;
		textArea = new JTextArea(15, 50);
		textArea.setEditable(false);
		add(new JScrollPane(textArea), gbc);

		// Adicionar ActionListeners
		listarDespesasButton.addActionListener(e -> listarDespesas());
		listarPagamentosButton.addActionListener(e -> {
			try {
				listarPagamentos();
			} catch (ProcessoNotFoundException ex) {
				// Registra a exceção com uma mensagem descritiva
				Logger.getLogger(getClass().getName()).log(Level.SEVERE, "Processo não encontrado ao listar pagamentos",
						ex);

				// Exibe uma mensagem de erro amigável para o usuário
				JOptionPane.showMessageDialog(null,
						"Ocorreu um erro ao listar os pagamentos. Verifique se o processo está registrado e tente novamente.",
						"Erro ao Listar Pagamentos", JOptionPane.ERROR_MESSAGE);
			} catch (PessoaException ex) {
				// Registra a exceção com uma mensagem descritiva
				Logger.getLogger(getClass().getName()).log(Level.SEVERE, "Erro com a pessoa ao listar pagamentos", ex);

				// Exibe uma mensagem de erro amigável para o usuário
				JOptionPane.showMessageDialog(null,
						"Ocorreu um erro com os dados da pessoa ao listar os pagamentos. Verifique os dados e tente novamente.",
						"Erro ao Listar Pagamentos", JOptionPane.ERROR_MESSAGE);
			}
		});

		listarExtratoButton.addActionListener(e -> listarExtratoCompleto());
		adicionarPagamentoButton.addActionListener(e -> adicionarPagamento());
		adicionarDespesaButton.addActionListener(e -> adicionarDespesa());
	}

	private long obterNumeroProcesso() throws NumberFormatException {
		String textoNumeroProcesso = textNumeroProcesso.getText().trim();
		if (textoNumeroProcesso.isEmpty()) {
			throw new NumberFormatException("O número do processo não pode ser vazio.");
		}
		return Long.parseLong(textoNumeroProcesso); // Conversão de String para long
	}

	private void listarDespesas() {
		ProcessoController controllerProcesso = MainController.getProcessoController();
		try {
			long numeroProcesso = obterNumeroProcesso(); // Método ajustado para obter long
			if (numeroProcesso == 0) {
				JOptionPane.showMessageDialog(this, "Número do processo não pode ser vazio.", "Erro",
						JOptionPane.ERROR_MESSAGE);
				return;
			}

			// Buscar o Processo pelo número
			Processo processo = controllerProcesso.findProcessoByNumero(numeroProcesso);
			if (processo == null) {
				JOptionPane.showMessageDialog(this, "Processo não encontrado.", "Erro", JOptionPane.ERROR_MESSAGE);
				return;
			}

			// Obtém o ContaController para listar despesas da conta vinculada ao processo
			StringBuilder sb = new StringBuilder();
			sb.append("Despesas:\n");

			DespesaController controllerDespesa = MainController.getDespesaController();

			// Obter a lista de despesas do processo, usando o objeto Processo diretamente
			for (Despesa despesa : controllerDespesa.getDespesas(processo)) {
				sb.append(despesa.toString()).append("\n");
			}

			textArea.setText(sb.toString());
		} catch (ContaException e) {
			JOptionPane.showMessageDialog(this, "Erro ao listar despesas: " + e.getMessage(), "Erro",
					JOptionPane.ERROR_MESSAGE);
		} catch (NumberFormatException e) {
			JOptionPane.showMessageDialog(this, "O número do processo deve ser um valor numérico.", "Erro",
					JOptionPane.ERROR_MESSAGE);
		}
	}

	private void listarPagamentos() throws ProcessoNotFoundException, PessoaException {

		try {

			long numeroProcesso = obterNumeroProcesso();
			if (numeroProcesso == 0) {
				JOptionPane.showMessageDialog(this, "Número do processo não pode ser vazio.", "Erro",
						JOptionPane.ERROR_MESSAGE);
				return;
			}

			StringBuilder sb = new StringBuilder();
			sb.append("Pagamentos:\n");
			PagamentoController pagamentoController = MainController.getPagamentoController();

			for (Pagamento pagamento : pagamentoController.getPagamentos(numeroProcesso)) {
				sb.append(pagamento.toString()).append("\n");
			}
			textArea.setText(sb.toString());
		} catch (ContaException e) {
			JOptionPane.showMessageDialog(this, "Erro ao listar pagamentos: " + e.getMessage(), "Erro",
					JOptionPane.ERROR_MESSAGE);
		}
	}

	private void listarExtratoCompleto() {
		try {
			long numeroProcesso = obterNumeroProcesso();
			if (numeroProcesso == 0) {
				JOptionPane.showMessageDialog(this, "Número do processo não pode ser vazio.", "Erro",
						JOptionPane.ERROR_MESSAGE);
				return;
			}

			ContaController contaController = MainController.getContaController();
			String extratoCompleto = contaController.getExtratoCompleto(numeroProcesso);
			textArea.setText("Extrato Completo:\n" + extratoCompleto);
		} catch (ContaException e) {
			JOptionPane.showMessageDialog(this, "Erro ao listar extrato completo: " + e.getMessage(), "Erro",
					JOptionPane.ERROR_MESSAGE);
		}
	}

	private void adicionarPagamento() {
		JPanel panel = new JPanel(new GridLayout(0, 2));
		JTextField textDataPagamento = new JTextField(10);
		JTextField textValorPagamento = new JTextField(10);
		JTextField textFormaPagamento = new JTextField(10);

		panel.add(new JLabel("Data (dd/MM/yyyy):"));
		panel.add(textDataPagamento);
		panel.add(new JLabel("Valor:"));
		panel.add(textValorPagamento);
		panel.add(new JLabel("Forma de Pagamento:"));
		panel.add(textFormaPagamento);

		int result = JOptionPane.showConfirmDialog(this, panel, "Adicionar Pagamento", JOptionPane.OK_CANCEL_OPTION);
		if (result == JOptionPane.OK_OPTION) {
			try {
				long numeroProcesso = obterNumeroProcesso();
				if (numeroProcesso == 0) {
					JOptionPane.showMessageDialog(this, "Número do processo não pode ser vazio.", "Erro",
							JOptionPane.ERROR_MESSAGE);
					return;
				}

				SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
				Date dataPagamento = sdf.parse(textDataPagamento.getText());
				double valorPagamento = Double.parseDouble(textValorPagamento.getText());
				EFormaPagamento formaPagamento = EFormaPagamento.valueOf(textFormaPagamento.getText().toUpperCase());

				Pagamento pagamento = new Pagamento(dataPagamento, valorPagamento, formaPagamento);
				PagamentoController pagamentoController = MainController.getPagamentoController();

				// Verifica o total de despesas antes de adicionar o pagamento
				ContaController contaController = MainController.getContaController();
				ProcessoController processoController = MainController.getProcessoController();
				Conta conta = contaController
						.getContaByProcesso(processoController.getProcessoByNumero(numeroProcesso));
				double totalDespesas = conta.getTotalDespesas();

				if (totalDespesas <= 0) {
					JOptionPane.showMessageDialog(this, "Não há despesas para permitir o pagamento.", "Erro",
							JOptionPane.ERROR_MESSAGE);
					return;
				}

				if (valorPagamento <= 0 || valorPagamento > totalDespesas) {
					JOptionPane.showMessageDialog(this,
							"Valor do pagamento inválido. Deve ser maior que 0 e não pode exceder o total de despesas.",
							"Erro", JOptionPane.ERROR_MESSAGE);
					return;
				}

				pagamentoController.addPagamento(numeroProcesso, pagamento);
				JOptionPane.showMessageDialog(this, "Pagamento adicionado com sucesso.");
			} catch (Exception e) {
				JOptionPane.showMessageDialog(this, "Erro ao adicionar pagamento: " + e.getMessage(), "Erro",
						JOptionPane.ERROR_MESSAGE);
			}
		}
	}

	private void adicionarDespesa() {
		JPanel panel = new JPanel(new GridLayout(0, 2));
		JTextField textDataDespesa = new JTextField(10);
		JTextField textValorDespesa = new JTextField(10);
		JTextField textDescricaoDespesa = new JTextField(10);

		panel.add(new JLabel("Data (dd/MM/yyyy):"));
		panel.add(textDataDespesa);
		panel.add(new JLabel("Valor:"));
		panel.add(textValorDespesa);
		panel.add(new JLabel("Descrição:"));
		panel.add(textDescricaoDespesa);

		int result = JOptionPane.showConfirmDialog(this, panel, "Adicionar Despesa", JOptionPane.OK_CANCEL_OPTION);
		if (result == JOptionPane.OK_OPTION) {
			try {
				long numeroProcesso = obterNumeroProcesso();
				if (numeroProcesso == 0) {
					JOptionPane.showMessageDialog(this, "Número do processo não pode ser vazio.", "Erro",
							JOptionPane.ERROR_MESSAGE);
					return;
				}

				SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
				Date dataDespesa = sdf.parse(textDataDespesa.getText());
				double valorDespesa = Double.parseDouble(textValorDespesa.getText());
				String descricaoDespesa = textDescricaoDespesa.getText();

				Despesa despesa = new Despesa(dataDespesa, descricaoDespesa, valorDespesa);
				DespesaController despesaController = MainController.getDespesaController();
				despesaController.addDespesa(numeroProcesso, despesa);
				JOptionPane.showMessageDialog(this, "Despesa adicionada com sucesso.");
			} catch (Exception e) {
				JOptionPane.showMessageDialog(this, "Erro ao adicionar despesa: " + e.getMessage(), "Erro",
						JOptionPane.ERROR_MESSAGE);
			}
		}
	}

}
