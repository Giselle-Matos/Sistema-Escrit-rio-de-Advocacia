package view;

import javax.swing.JFrame;
import javax.swing.JTabbedPane;

public class MainView extends JFrame {

	private static final long serialVersionUID = 1L;

	private JTabbedPane tabbedPane;
	private TribunalView tribunalView;
	private PessoaView pessoaView;
	private ProcessoView processoView;
	private ContaView contaView;

	public MainView() {
		setTitle("Sistema de Gestão Jurídica");
		setSize(600, 400);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		// Criando o JTabbedPane
		tabbedPane = new JTabbedPane();

		// Adiciona o JTabbedPane à janela principal
		getContentPane().add(tabbedPane);

		// Adicionando as abas ao tabbedPane
		tribunalView = new TribunalView();
		pessoaView = new PessoaView();
		processoView = new ProcessoView();
		contaView = new ContaView();

		tabbedPane.addTab("Tribunal", tribunalView);
		tabbedPane.addTab("Pessoa", pessoaView);
		tabbedPane.addTab("Processo", processoView);
		tabbedPane.addTab("Conta", contaView);

		// Mostra a janela
		setVisible(true);
	}

	public static void main(String[] args) {
		new MainView();
	}
}
