package main;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JTabbedPane;

import controller.MainController;
import view.ContaView;
import view.PessoaView;
import view.ProcessoView;
import view.TribunalView;

public class Main {

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {

			public void run() {

				try {
					MainController.load();
					MainController.getInstance();
					JTabbedPane tabbedPane = new JTabbedPane();

					// Cria as views
					TribunalView tribunalView = new TribunalView();
					PessoaView pessoaView = new PessoaView();
					ProcessoView processoView = new ProcessoView();
					ContaView contaView = new ContaView();

					// Adiciona as abas no tabbedPane
					tabbedPane.addTab("Tribunal", tribunalView);
					tabbedPane.addTab("Pessoa", pessoaView); // Exemplo para outra aba
					tabbedPane.addTab("Processo", processoView); // Exemplo para outra aba
					tabbedPane.addTab("Conta", contaView); // Exemplo para outra aba

					// Exibe a tela principal
					JFrame frame = new JFrame("Sistema de Gestão Jurídica");
					frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
					frame.add(tabbedPane); // Adiciona o tabbed pane ao frame
					frame.pack();
					frame.setLocationRelativeTo(null); // Centraliza a janela
					frame.setVisible(true);

				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

}
