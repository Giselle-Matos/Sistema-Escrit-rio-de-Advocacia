package controller;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import exceptions.ContaException;
import exceptions.PessoaException;
import exceptions.ProcessoNotFoundException;
import model.Conta;
import model.Pagamento;
import model.Processo;

public class PagamentoController implements Serializable {

	private static final long serialVersionUID = 430190793758178366L;

	// Métodos de addPagamento e getPagamentos aqui

	public void addPagamento(long numeroProcesso, Pagamento pagamento)
			throws ContaException, ProcessoNotFoundException, PessoaException {

		if (pagamento == null) {
			throw new ContaException("Pagamento não pode ser nulo.");
		}

		ProcessoController processoController = MainController.getProcessoController();
		Processo processo = processoController.getProcessoByNumero(numeroProcesso);

		ContaController contaController = MainController.getContaController(); // Obtenha o ContaController
		Conta conta = contaController.getContaByProcesso(processo);

		if (conta == null) {
			throw new ContaException("Conta não encontrada para o número do processo.");
		}

		double totalDespesas = conta.getTotalDespesas(); // Assumindo que você tem um método para obter o total de
															// despesas

		if (totalDespesas <= 0) {
			throw new ContaException("Não há despesas para permitir o pagamento.");
		}

		double valorPagamento = pagamento.getValor();
		if (valorPagamento <= 0 || valorPagamento > totalDespesas) {
			throw new ContaException(
					"Valor do pagamento inválido. Deve ser maior que 0 e não pode exceder o total de despesas.");
		}

		conta.addPagamento(pagamento.getData(), pagamento.getValor(), pagamento.getFormaPagamento());
		MainController.save();
	}

	public List<Pagamento> getPagamentos(long numeroProcesso)
			throws ContaException, ProcessoNotFoundException, PessoaException {
		ContaController contaController = MainController.getContaController(); // Obtenha o ContaController

		ProcessoController processoController = MainController.getProcessoController();
		Processo processo = processoController.getProcessoByNumero(numeroProcesso);

		Conta conta = contaController.getContaByProcesso(processo);
		if (conta == null) {
			throw new ContaException("Conta não encontrada para o número do processo.");
		}

		List<Pagamento> pagamentos = new ArrayList<>();
		for (Pagamento pagamento : conta.getPagamentos()) {
			pagamentos.add(new Pagamento(pagamento.getData(), pagamento.getValor(), pagamento.getFormaPagamento()));
		}
		return pagamentos;
	}
}
