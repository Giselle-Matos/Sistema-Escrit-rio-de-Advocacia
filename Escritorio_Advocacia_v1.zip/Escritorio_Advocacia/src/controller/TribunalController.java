package controller;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

import exceptions.TribunalException;
import model.Tribunal;
import util.IsValidDescricao;
import util.IsValidSigla;

public class TribunalController implements Serializable {

	private static final long serialVersionUID = 5925029020357709586L;

	private Map<String, Tribunal> tribunais;

	public TribunalController() {
		tribunais = new TreeMap<>();
	}

	public void addTribunal(Tribunal tribunal) throws TribunalException {
		// Verificação de campos obrigatórios
		if (tribunal.getSigla().isEmpty() || tribunal.getDescricao().isEmpty() || tribunal.getSecao().isEmpty()) {
			throw new TribunalException("Todos os campos são obrigatórios.");
		}

		// Validação da sigla
		if (!IsValidSigla.validate(tribunal.getSigla())) {
			throw new TribunalException("A sigla contém caracteres inválidos.");
		}

		// Validação da descrição
		if (!IsValidDescricao.validate(tribunal.getDescricao())) {
			throw new TribunalException("A descrição contém caracteres inválidos.");
		}

		// Verifica se a sigla já existe
		if (getTribunalBySigla(tribunal.getSigla()) != null) {
			throw new TribunalException("Sigla já existente.");
		}

		// Cria o novo tribunal
		Tribunal novoTribunal = new Tribunal(tribunal.getSigla(), tribunal.getDescricao(), tribunal.getSecao());
		tribunais.put(novoTribunal.getSigla(), novoTribunal);

		// Salva as alterações
		MainController.save();
	}

	public Tribunal getTribunalBySigla(String sigla) {
		return tribunais.get(sigla);
	}

	public Set<String> getSiglasTribunais() {
		return tribunais.keySet();
	}

	public List<Tribunal> getTribunais() throws TribunalException {
		List<Tribunal> lista = new ArrayList<>();
		for (Tribunal t : tribunais.values()) {
			lista.add(new Tribunal(t.getSigla(), t.getDescricao(), t.getSecao()));
		}
		return lista;
	}

	public Map<String, Tribunal> getTribunaisMap() {
		return tribunais;
	}

	public Tribunal buscarTribunalPorSigla(String sigla) {
		if (sigla == null || sigla.trim().isEmpty()) {
			throw new IllegalArgumentException("Sigla do tribunal não pode ser nula ou vazia.");
		}

		TribunalController controllerTribunal = MainController.getTribunalController();
		return controllerTribunal.getTribunalBySigla(sigla);
	}

}
