package controller;

import java.io.Serializable;
import java.util.Map;
import java.util.TreeMap;

import exceptions.ContaException;
import model.Conta;
import model.Processo;

public class ContaController implements Serializable {

	private static final long serialVersionUID = 6140827116840047871L;

	private Map<String, Conta> contas; // Usa o número do processo como chave para encontrar a conta

	public ContaController() {
		contas = new TreeMap<>();
	}

	// Obtém o saldo atual da conta
	public double getSaldo(String numeroProcesso) throws ContaException {
		Conta conta = contas.get(numeroProcesso);
		if (conta == null) {
			throw new ContaException("Conta não encontrada para o número do processo.");
		}
		return conta.getSaldoConta();
	}

	// Obtém o extrato da conta
	public String getExtrato(long numeroProcesso) throws ContaException {
		Conta conta = contas.get(String.valueOf(numeroProcesso)); // Convert long to String
		if (conta == null) {
			throw new ContaException("Conta não encontrada para o número do processo.");
		}
		return conta.getExtrato().toString();
	}

	public String getExtratoCompleto(long numeroProcesso) throws ContaException {
		Conta conta = contas.get(String.valueOf(numeroProcesso)); // Convert long to String
		if (conta == null) {
			throw new ContaException("Conta não encontrada para o número do processo.");
		}
		return conta.getExtrato().toString();
	}

	// Adiciona uma nova conta ao controlador
	public void addConta(String numeroProcesso, Conta conta) {
		contas.put(numeroProcesso, conta);
	}

	// Obtém a conta pelo número do processo
	public Conta getConta(String numeroProcesso) {
		return contas.get(numeroProcesso);
	}

	public Conta getContaByProcesso(Processo processo) {
		return contas.computeIfAbsent(String.valueOf(processo.getNumero()), k -> new Conta());
	}
}
