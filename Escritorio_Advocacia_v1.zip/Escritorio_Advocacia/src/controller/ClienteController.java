package controller;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import model.Cliente;
import model.Pessoa;
import model.PessoaFisica;

public class ClienteController implements Serializable {

	private static final long serialVersionUID = 5728903463414850216L;

	private List<Cliente> clientes = new ArrayList<>(); // Lista de clientes

	// Supondo que você tenha uma lista de processos armazenados em algum lugar
	public ClienteController() {
		clientes = new ArrayList<>();
	}

	// Helper method to search for a client by CPF or CNPJ
	public Cliente buscarClientePorCpfOuCnpj(String cpfOuCnpj, boolean isCpf) {
		PessoaController controllerPessoa = MainController.getPessoaController();

		System.out.println("ENTROU EM  buscarClientePorCpfOuCnpj");
		for (Cliente cliente : clientes) {
			System.out.println(controllerPessoa.getPessoas());

			Pessoa pessoa = cliente.getPessoa();
			if (pessoa instanceof PessoaFisica) {
				PessoaFisica pessoaFisica = (PessoaFisica) pessoa;
				if (isCpf && pessoaFisica.getRegistroRF().equals(cpfOuCnpj)) {
					return cliente;
				} else if (!isCpf && pessoaFisica.getRegistroRF().equals(cpfOuCnpj)) {
					return cliente;
				}
			}
		}
		if (isCpf) {
			System.out.println("controllerPessoa.getPessoaByCPF(cpfOuCnpj)");
			System.out.println(controllerPessoa.getPessoaByCPF(cpfOuCnpj));
			Pessoa pessoa = controllerPessoa.getPessoaByCPF(cpfOuCnpj);
			Cliente cliente = new Cliente(pessoa);
			return cliente;
		} else if (!isCpf) {
			Pessoa pessoa = controllerPessoa.getPessoaByCNPJ(cpfOuCnpj);
			Cliente cliente = new Cliente(pessoa);
			return cliente;
		}
		return null;
	}

	public void adicionarCliente(Cliente cliente) {
		clientes.add(cliente);
	}

}
