package controller;

import java.io.Serializable;
import java.util.List;

import exceptions.ContaException;
import exceptions.PessoaException;
import exceptions.ProcessoNotFoundException;
import model.Conta;
import model.Despesa;
import model.Processo;

public class DespesaController implements Serializable {

    private static final long serialVersionUID = 7764719325061255806L;

    private ContaController contaController;

    public DespesaController(ContaController contaController) {
        this.contaController = contaController;
    }

    // Obter lista de despesas de uma conta associada ao processo
    public List<Despesa> getDespesas(Processo processo) throws ContaException {
        ContaController contaController = MainController.getContaController();
        
        Conta conta = contaController.getContaByProcesso(processo);
        return conta.getDespesas();
    }

    // Adiciona uma despesa à conta associada ao processo
    public void addDespesa(long numeroProcesso, Despesa despesaDTO) throws ContaException, ProcessoNotFoundException, PessoaException {
        if (despesaDTO == null) {
            throw new ContaException("Despesa não pode ser nula.");
        }
        
        ProcessoController processoController = MainController.getProcessoController();
        Processo processo = processoController.getProcessoByNumero(numeroProcesso);

        Conta conta = contaController.getContaByProcesso(processo);
        if (conta == null) {
            throw new ContaException("Conta não encontrada para o número do processo.");
        }

        Despesa despesa = new Despesa(despesaDTO.getData(), despesaDTO.getDescricao(), despesaDTO.getValor());
        conta.addDespesa(despesa.getData(), despesa.getDescricao(), despesa.getValor());

        // Salva o estado do sistema
        MainController.save();
    }
}
