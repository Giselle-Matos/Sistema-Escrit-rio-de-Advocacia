package controller;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import javax.swing.JOptionPane;

import exceptions.PessoaException;
import exceptions.ProcessoNotFoundException;
import model.Audiencia;
import model.Cliente;
import model.Conta;
import model.EFaseProcesso;
import model.Pessoa;
import model.Processo;
import model.Tribunal;

public class ProcessoController implements Serializable {

	private static final long serialVersionUID = -4207972541349534602L;

	private Map<Long, Processo> processos;

	public ProcessoController() {
		processos = new TreeMap<>();
	}

	public void addProcesso(Processo processo) throws Exception {
		long numero = processo.getNumero();
		Date dataAbertura = processo.getDataAbertura();
		Date dataConclusao = processo.getDataConclusao();
		EFaseProcesso fase = processo.getFase();
		Pessoa parteContraria = processo.getParteContraria();
		Cliente cliente = processo.getCliente();
		Tribunal tribunal = processo.getTribunal();
		Conta conta = processo.getConta();

		Processo processo1 = new Processo(numero, dataAbertura, parteContraria, tribunal, conta, cliente);

		if (dataConclusao != null) {
			processo1.setDataConclusao(dataConclusao);
		}

		if (fase != null) {
			processo1.setFase(fase);
		}
		cliente.addProcesso(processo1);

		processos.put(numero, processo1);
		MainController.save();
	}

	public Processo getProcessoByNumero(long numero) throws ProcessoNotFoundException, PessoaException {
		Processo processo = processos.get(numero);
		if (processo == null) {
			throw new ProcessoNotFoundException("Processo não encontrado.");
		}

		List<Audiencia> audienciasList = new ArrayList<>();
		StringBuilder descricaoAudiencias = new StringBuilder();

		// Iterating through the list of audiencias associated with the processo
		for (Audiencia audiencia : processo.getAudiencias()) {
			// Creating AdvogadoDTO for each audiencia

			audienciasList.add(audiencia);

			// Accumulating the description of the audiencias
			descricaoAudiencias.append("Audiência em ").append(audiencia.getData()).append(" com recomendação: ")
					.append(audiencia.getRecomendacao()).append("\n");
		}

		// Returning the updated Processo object with the accumulated audience
		// description
		return new Processo(processo.getNumero(), processo.getDataAbertura(), processo.getParteContraria(),
				processo.getTribunal(), processo.getConta(), processo.getCliente());
	}

	public List<Processo> getProcessos() throws PessoaException {
		return new ArrayList<>(processos.values()); // Retorna todos os processos na lista
	}

	public boolean existeProcessoComNumero(long numero) {
		return processos.containsKey(numero);
	}

	public Processo findProcessoByNumero(long numero) {
		return processos.get(numero); // Retorna o processo associado ao número ou null se não encontrado
	}

	// Método para atualizar um processo existente
	public void atualizarProcesso(Processo processo) {
		try {
			// Aqui o processo já foi atualizado diretamente no método
			// abrirProcessoParaEdicao
			// Portanto, apenas precisa confirmar a atualização

			JOptionPane.showMessageDialog(null, "Processo atualizado com sucesso!");
		} catch (Exception e) {
			JOptionPane.showMessageDialog(null, "Erro ao atualizar processo: " + e.getMessage());
		}
	}

}
