package controller;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import exceptions.AdvogadoNaoEncontradoException;
import model.Advogado;

public class AdvogadoController implements Serializable {

	private static final long serialVersionUID = -4984564085419752823L;

	private List<Advogado> advogados = new ArrayList<>(); // Lista de advogados

	// Método para encontrar um advogado pelo CPF
	// Método fictício para encontrar um advogado pelo CPF

	public Advogado findAdvogadoByCpf(String cpf) {
		AdvogadoController advogadoController = new AdvogadoController();

		Advogado advogado = advogadoController.findAdvogadoByCpf(cpf);
		return advogado;

	}

	public Advogado buscarAdvogadoPorNome(String nome) {
		if (nome == null || nome.trim().isEmpty()) {
			throw new IllegalArgumentException("Nome do advogado não pode ser nulo ou vazio.");
		}

		for (Advogado advogado : advogados) {
			if (advogado.getNome().equalsIgnoreCase(nome)) {
				return advogado;
			}
		}
		return null;
	}

	public Advogado buscarAdvogadoPorRegistro(String registroAdvogado) throws AdvogadoNaoEncontradoException {
		if (registroAdvogado == null || registroAdvogado.trim().isEmpty()) {
			throw new IllegalArgumentException("Registro do advogado não pode ser nulo ou vazio.");
		}

		for (Advogado advogado : advogados) {
			if (advogado.getRegistro().equals(registroAdvogado)) {
				return advogado;
			}
		}

		throw new AdvogadoNaoEncontradoException("Advogado com registro " + registroAdvogado + " não encontrado.");
	}

	public void adicionarAdvogado(Advogado advogado) {
		if (advogado == null) {
			throw new IllegalArgumentException("Advogado não pode ser nulo.");
		}
		advogados.add(advogado);
	}
}
