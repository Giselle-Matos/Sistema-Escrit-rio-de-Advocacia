package controller;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import exceptions.CnpjInvalidoException;
import exceptions.CpfInvalidoException;
import exceptions.PessoaException;
import model.Advogado;
import model.Pessoa;
import model.PessoaFisica;
import model.PessoaJuridica;
import util.IsEmailValid;
import util.IsValidCNPJ;
import util.IsValidCPF;

public class PessoaController implements Serializable {

	private static final long serialVersionUID = 2095219152717152518L;

	private Map<String, Pessoa> pessoas;
	private Map<String, PessoaFisica> pessoasFisicas;

	public PessoaController() {
		pessoas = new TreeMap<>();
		pessoasFisicas = new TreeMap<>();

	}

	public void addPessoa(Pessoa pessoa, String tipoPessoa) throws PessoaException {
		// String tipoPessoa = pessoa.getTipoPessoa();
		Pessoa novaPessoa;
		

		// Validação de email
		if (!IsEmailValid.isValid(pessoa.getEmail())) {
			throw new PessoaException("Email inválido.");
		}

		if ("Pessoa Física".equalsIgnoreCase(tipoPessoa)) {
			String cpf = pessoa.getRegistroRF();
			if (!IsValidCPF.isValid(cpf)) {
				throw new CpfInvalidoException();
			}
			novaPessoa = new PessoaFisica(pessoa.getNome(), cpf, pessoa.getEmail(), pessoa.getTelefone());
		} else if ("Pessoa Jurídica".equalsIgnoreCase(tipoPessoa)) {
			PessoaJuridica pj = (PessoaJuridica) pessoa;
			
			String cnpj = pj.getRegistroRF();
			if (!IsValidCNPJ.isValid(cnpj)) {
				throw new CnpjInvalidoException();
			}

			PessoaFisica preposto = null;
			if (pj.getPreposto() != null && !(pj.getPreposto() == null)) {
				String cpfPreposto = pj.getPreposto().getRegistroRF();
				if (!IsValidCPF.isValid(cpfPreposto)) {
					throw new CpfInvalidoException();
				}

				preposto = getPrepostoByCPF(cpfPreposto); // Buscando o preposto
				if (preposto == null) {
					throw new PessoaException("Preposto com CPF " + cpfPreposto + " não encontrado no sistema.");
				}
			}

			novaPessoa = new PessoaJuridica(pj.getNome(), cnpj, preposto, pj.getEmail(), pj.getTelefone());
			System.out.println(novaPessoa.toString());

		} else if ("Advogado".equalsIgnoreCase(tipoPessoa)) {
			System.out.println("DENTRO DE ADVOGADO");
			Advogado advogado = (Advogado) pessoa;

			String cpf = advogado.getRegistroRF();
			if (!IsValidCPF.isValid(cpf)) {
				System.out.println(!IsValidCPF.isValid(cpf));
				throw new CpfInvalidoException();
			}
			String registroAdvogado = advogado.getRegistro();
			if (registroAdvogado == null || registroAdvogado.trim().isEmpty()) {
				throw new PessoaException("Registro do Advogado não pode ser vazio.");
			}
			novaPessoa = new Advogado(advogado.getNome(), registroAdvogado, advogado.getEmail(), advogado.getTelefone(),
					cpf);
		} else {
			throw new PessoaException("Tipo de pessoa desconhecido.");
		}

		if (pessoas.containsKey(novaPessoa.getRegistroRF())) {
			throw new PessoaException("Pessoa já existente.");
		}
		pessoas.put(novaPessoa.getRegistroRF(), novaPessoa);

		MainController.save(); // Salva os dados
	}

	public Pessoa getPessoaByCPF(String registro) {
		for (Pessoa pessoa : pessoas.values()) {
			System.out.println("getPessoaByCPF antes do if");
			System.out.println(pessoa instanceof PessoaFisica);
			System.out.println(pessoa.getRegistroRF().equals(registro));
			if (pessoa instanceof PessoaFisica && pessoa.getRegistroRF().equals(registro)) {

				return pessoa;
			}
		}
		return null;
	}

	public Pessoa getPessoaByCNPJ(String cnpj) {
		for (Pessoa pessoa : pessoas.values()) {
			if (pessoa instanceof PessoaJuridica && pessoa.getRegistroRF().equals(cnpj)) {
				return pessoa;
			}
		}
		return null;
	}

	public Map<String, Pessoa> getPessoasMap() {
		return pessoas;
	}

	public List<Pessoa> getPessoas() {
		List<Pessoa> lista = new ArrayList<>();
		for (Pessoa p : pessoas.values()) {
			if (p instanceof PessoaFisica) {
				// Adiciona diretamente a pessoa física à lista
				lista.add(p);
			} else if (p instanceof PessoaJuridica) {
				// Adiciona diretamente a pessoa jurídica à lista
				lista.add(p);
			} else if (p instanceof Advogado) {
				// Adiciona diretamente o advogado à lista
				lista.add(p);
			}
		}
		return lista;
	}

	public Pessoa buscarParteContraria(String registro, boolean isCPF) throws Exception {
		String parteContraria = registro;

		PessoaController controllerPessoa = MainController.getPessoaController();

		if (parteContraria.isEmpty()) {
			throw new IllegalArgumentException("Campo de CPF/CNPJ não pode estar vazio.");
		}

		if (isCPF) {
			System.out.println("isCPF!!!!!");
			System.out.println(IsValidCPF.isValid(parteContraria));
			if (!IsValidCPF.isValid(parteContraria)) {

				throw new IllegalArgumentException("CPF inválido.");
			}

			System.out.println(controllerPessoa.getPessoaByCPF(parteContraria));

			Pessoa pessoa = controllerPessoa.getPessoaByCPF(parteContraria);

			return pessoa;

		} else {
			if (!IsValidCNPJ.isValid(parteContraria)) {
				throw new IllegalArgumentException("CNPJ inválido.");
			}
			Pessoa pessoa = controllerPessoa.getPessoaByCNPJ(parteContraria);

			return pessoa;
		}
	}

	// Método para adicionar uma Pessoa Física
	public void adicionarPessoaFisica(PessoaFisica pessoa) throws PessoaException {
		// Verifique se o CPF é válido
		if (!IsValidCPF.isValid(pessoa.getRegistroRF())) {
			throw new CpfInvalidoException();
		}

		// Adiciona a nova pessoa física
		if (pessoasFisicas.containsKey(pessoa.getRegistroRF())) {
			throw new PessoaException("Pessoa com CPF " + pessoa.getRegistroRF() + " já está cadastrada.");
		}

		pessoasFisicas.put(pessoa.getRegistroRF(), pessoa);
		System.out.println("Pessoa adicionada: " + pessoa.getNome());
	}

	public PessoaFisica getPrepostoByCPF(String cpf) throws PessoaException {
		if (pessoasFisicas == null || pessoasFisicas.isEmpty()) {
			throw new PessoaException("A lista de pessoas físicas está vazia ou não inicializada.");
		}

		for (PessoaFisica pessoa : pessoasFisicas.values()) {

			if (pessoa.getRegistroRF().equals(cpf)) {
				return pessoa;
			}
		}

		throw new PessoaException("Preposto com CPF " + cpf + " não encontrado.");
	}
}
