
package exceptions;

public class CnpjInvalidoException extends PessoaException {

	private static final long serialVersionUID = 8604234115295244016L;

	public CnpjInvalidoException() {
		super("CNPJ inválido.");
	}
}
