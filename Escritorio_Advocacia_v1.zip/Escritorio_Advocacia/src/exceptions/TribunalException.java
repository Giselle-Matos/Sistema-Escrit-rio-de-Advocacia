package exceptions;

import java.io.Serializable;

public class TribunalException extends Exception implements Serializable {

	private static final long serialVersionUID = 1935563749083322920L;

	public TribunalException(String message) {
		super(message);
	}
}
