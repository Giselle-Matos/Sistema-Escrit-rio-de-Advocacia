package exceptions;

public class NenhumProcessoEncontradoException extends Exception {
    private static final long serialVersionUID = -1197479036492668292L;

	public NenhumProcessoEncontradoException(String mensagem) {
        super(mensagem);
    }
}
