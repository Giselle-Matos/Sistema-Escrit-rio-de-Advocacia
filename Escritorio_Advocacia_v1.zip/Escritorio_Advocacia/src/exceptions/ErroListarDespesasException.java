package exceptions;

public class ErroListarDespesasException extends Exception {
	private static final long serialVersionUID = -6544704497699063355L;

	public ErroListarDespesasException() {
		super("Erro ao listar despesas.");
	}

	public ErroListarDespesasException(String message) {
		super(message);
	}
}
