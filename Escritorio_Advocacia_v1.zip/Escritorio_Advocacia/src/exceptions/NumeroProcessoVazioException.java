package exceptions;

public class NumeroProcessoVazioException extends Exception {
	private static final long serialVersionUID = 9080903422851286494L;

	public NumeroProcessoVazioException() {
		super("Número do processo não pode ser vazio.");
	}

	public NumeroProcessoVazioException(String message) {
		super(message);
	}
}
