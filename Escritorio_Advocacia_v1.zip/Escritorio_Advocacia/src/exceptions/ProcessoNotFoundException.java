package exceptions;

public class ProcessoNotFoundException extends Exception {

	private static final long serialVersionUID = -3014114910348039783L;

	public ProcessoNotFoundException(String message) {
		super(message);
	}
}
