package exceptions;

public class NomeInvalidoException extends PessoaException {

	private static final long serialVersionUID = 609249165559232706L;

	public NomeInvalidoException() {
		super("Nome não pode ser vazio.");
	}
}