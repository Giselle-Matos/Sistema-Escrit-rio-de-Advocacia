package exceptions;

public class CpfInvalidoException extends PessoaException {

	private static final long serialVersionUID = -8501408165537058222L;

	public CpfInvalidoException() {
		super("CPF Inválido");
	}
}
