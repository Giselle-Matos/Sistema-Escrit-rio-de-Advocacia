package exceptions;

public class DescricaoInvalidaException extends TribunalException {

	private static final long serialVersionUID = 1L;

	public DescricaoInvalidaException(String message) {
		super(message);
	}
}
