package exceptions;

public class TelefoneInvalidoException extends Exception {

	private static final long serialVersionUID = 1L;

	public TelefoneInvalidoException(String telefone) {
		super("Número de telefone inválido: " + telefone);
	}
}
