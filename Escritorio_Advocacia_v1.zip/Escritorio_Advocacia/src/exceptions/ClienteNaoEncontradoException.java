package exceptions;

public class ClienteNaoEncontradoException extends Exception {
	private static final long serialVersionUID = -5386660756340931489L;

	public ClienteNaoEncontradoException() {
		super("Nenhum cliente encontrado com o CPF informado.");
	}
}