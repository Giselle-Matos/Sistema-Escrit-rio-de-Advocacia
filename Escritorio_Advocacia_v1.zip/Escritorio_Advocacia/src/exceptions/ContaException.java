package exceptions;

public class ContaException extends Exception {

	private static final long serialVersionUID = 1L;

	public ContaException(String message) {
		super(message);
	}
}
