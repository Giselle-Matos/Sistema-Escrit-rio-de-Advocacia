package exceptions;

public class SiglaInvalidaException extends TribunalException {

	private static final long serialVersionUID = 1L;

	public SiglaInvalidaException(String message) {
		super(message);
	}
}
