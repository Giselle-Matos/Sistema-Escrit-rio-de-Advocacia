package exceptions;

public class AtualizacaoProcessoException extends RuntimeException {
    private static final long serialVersionUID = 1L;

    public AtualizacaoProcessoException() {
        super("Erro ao atualizar processo.");
    }

    public AtualizacaoProcessoException(String mensagem) {
        super(mensagem);
    }
}
