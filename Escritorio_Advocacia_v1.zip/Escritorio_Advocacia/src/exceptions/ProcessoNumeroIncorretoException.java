package exceptions;

public class ProcessoNumeroIncorretoException extends RuntimeException {
	private static final long serialVersionUID = 1L;

	public ProcessoNumeroIncorretoException() {
		super("Os números dos processos não correspondem.");
	}

	public ProcessoNumeroIncorretoException(String mensagem) {
		super(mensagem);
	}
}
