package exceptions;

public class RegistroInvalidoException extends PessoaException {

	private static final long serialVersionUID = -4447696935183083994L;

	public RegistroInvalidoException() {
		super("Registro não pode ser vazio");
	}
}
