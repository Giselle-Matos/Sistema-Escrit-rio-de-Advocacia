package exceptions;

public class CamposObrigatoriosException extends TribunalException {

    private static final long serialVersionUID = 1L;

    public CamposObrigatoriosException(String message) {
        super(message);
    }
}
