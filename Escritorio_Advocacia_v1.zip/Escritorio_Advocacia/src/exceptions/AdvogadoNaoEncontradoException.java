package exceptions;

public class AdvogadoNaoEncontradoException extends Exception {

	private static final long serialVersionUID = 1L;

	public AdvogadoNaoEncontradoException(String mensagem) {
		super(mensagem);
	}
}
