package util;

public class IsValidSigla {

	public static boolean validate(String sigla) {
		// Verifica se a sigla é nula ou não tem o comprimento correto
		if (sigla == null || sigla.length() != 4) {
			return false;
		}
		// Verifica se os primeiros 3 caracteres são letras e o último é um dígito
		return sigla.matches("[A-Za-z]{3}\\d");
	}
}
