package util;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class IsValidDate {

	private static final String DATE_FORMAT = "dd/MM/yyyy"; // Defina o formato da data esperado

	public boolean isValid(Date date) {
		if (date == null) {
			return false; // Verifica se a data não é nula
		}
		SimpleDateFormat sdf = new SimpleDateFormat(DATE_FORMAT);
		sdf.setLenient(false); // Isso garante que a data será rigorosamente validada
		try {
			String formattedDate = sdf.format(date);
			Date parsedDate = sdf.parse(formattedDate);
			return date.equals(parsedDate); // Verifica se a data é válida
		} catch (ParseException e) {
			return false; // Se ocorrer uma exceção, a data não é válida
		}
	}

	// Validação de data a partir de uma string
	public static boolean isValid(String dateStr) {
		SimpleDateFormat sdf = new SimpleDateFormat(DATE_FORMAT);
		sdf.setLenient(false);
		try {
			sdf.parse(dateStr);
			return true;
		} catch (ParseException e) {
			return false;
		}
	}
}
