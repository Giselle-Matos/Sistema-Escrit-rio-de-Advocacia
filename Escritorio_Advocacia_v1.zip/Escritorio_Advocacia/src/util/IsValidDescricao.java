package util;

public class IsValidDescricao {

	public static boolean validate(String descricao) {
		// Verifica se a descrição é nula
		if (descricao == null) {
			return false;
		}
		// Verifica se a descrição corresponde ao formato "Tribunal ABC2"
		// Permite letras, espaços e um número no final
		return descricao.matches("[A-Za-z ]{4,}[A-Z]{3}\\d");
	}
}
