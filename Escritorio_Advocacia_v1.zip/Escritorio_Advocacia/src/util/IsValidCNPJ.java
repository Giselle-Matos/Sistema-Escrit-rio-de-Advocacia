package util;

public class IsValidCNPJ {

    public static boolean isValid(String cnpj) {
        if (cnpj == null || cnpj.length() != 14) {
            return false;
        }
        
        // Remove caracteres não numéricos
        cnpj = cnpj.replaceAll("\\D", "");

        // Verifica se todos os dígitos são iguais
        if (cnpj.chars().distinct().count() == 1) {
            return false;
        }

        int[] pesos1 = {5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2};
        int[] pesos2 = {6, 5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2};

        // Calcula o primeiro dígito verificador
        int soma1 = 0;
        for (int i = 0; i < 12; i++) {
            soma1 += (cnpj.charAt(i) - '0') * pesos1[i];
        }
        int resto1 = (soma1 % 11);
        if (resto1 < 2) {
            resto1 = 0;
        } else {
            resto1 = 11 - resto1;
        }
        if (resto1 != (cnpj.charAt(12) - '0')) {
            return false;
        }

        // Calcula o segundo dígito verificador
        int soma2 = 0;
        for (int i = 0; i < 13; i++) {
            soma2 += (cnpj.charAt(i) - '0') * pesos2[i];
        }
        int resto2 = (soma2 % 11);
        if (resto2 < 2) {
            resto2 = 0;
        } else {
            resto2 = 11 - resto2;
        }
        return resto2 == (cnpj.charAt(13) - '0');
    }
}
