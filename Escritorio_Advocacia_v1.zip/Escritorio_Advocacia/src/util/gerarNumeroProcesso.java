package util;

import java.util.Random;

import controller.MainController;
import controller.ProcessoController;

public class gerarNumeroProcesso {

	// Método para gerar um número único de processo
	public static long gerarNumeroProcessoUnico() {
		ProcessoController controllerProcesso = MainController.getProcessoController();
		Random random = new Random();
		long numero;
		do {
			numero = random.nextLong() % 999999;
		} while (controllerProcesso.existeProcessoComNumero(numero));
		return numero;
	}
}
