package util;

public class IsValidCPF {

	public static boolean isValid(String cpf) {
		if (cpf == null || cpf.length() != 11 || !cpf.matches("\\d+")) {
			return false;
		}

		// Verifica se todos os dígitos são iguais (ex: 11111111111)
		if (cpf.chars().distinct().count() == 1) {
			return false;
		}

		int[] digits = cpf.chars().map(c -> c - '0').toArray();

		// Verifica o primeiro dígito verificador
		int sum1 = 0;
		for (int i = 0; i < 9; i++) {
			sum1 += digits[i] * (10 - i);
		}
		int remainder1 = (sum1 * 10) % 11;
		if (remainder1 == 10)
			remainder1 = 0;
		if (remainder1 != digits[9]) {
			return false;
		}

		// Verifica o segundo dígito verificador
		int sum2 = 0;
		for (int i = 0; i < 10; i++) {
			sum2 += digits[i] * (11 - i);
		}
		int remainder2 = (sum2 * 10) % 11;
		if (remainder2 == 10)
			remainder2 = 0;
		return remainder2 == digits[10];
	}
}
