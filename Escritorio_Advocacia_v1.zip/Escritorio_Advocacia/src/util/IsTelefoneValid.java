package util;

import java.util.regex.Pattern;

public class IsTelefoneValid {

	// Regex para validar números de telefone no formato nacional (Brasil)
	private static final String TELEFONE_REGEX = "\\(\\d{2}\\) \\d{4,5}-\\d{4}";

	// Valida se o número de telefone está no formato correto
	public static boolean isValid(String telefone) {
		if (telefone == null) {
			return false;
		}
		return Pattern.matches(TELEFONE_REGEX, telefone);
	}
}
