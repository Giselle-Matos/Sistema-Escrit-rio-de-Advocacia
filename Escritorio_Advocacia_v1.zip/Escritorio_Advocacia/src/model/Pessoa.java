package model;

import java.io.Serializable;

import exceptions.NomeInvalidoException;

public abstract class Pessoa implements Serializable {

	private static final long serialVersionUID = 4646913496716851519L;

	private String nome;
	private String email;
	private String telefone;

	public Pessoa(String nome, String email, String telefone) throws NomeInvalidoException {
		if (nome == null || nome.trim().isEmpty()) {
			throw new NomeInvalidoException();
		}
		this.nome = nome;
		this.email = email != null ? email : "";
		this.telefone = telefone != null ? telefone : "";
	}

	public String getNome() {
		return this.nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getEmail() {
		return this.email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getTelefone() {
		return this.telefone;
	}

	public abstract String getRegistroRF();

	public abstract String getTipoPessoa();

	@Override
	public String toString() {
		return String.format("Pessoa [nome=%s, email=%s, telefone=%s]", (nome != null ? nome : "null"),
				(email != null ? email : "null"), (telefone != null ? telefone : "null"));
	}
}
