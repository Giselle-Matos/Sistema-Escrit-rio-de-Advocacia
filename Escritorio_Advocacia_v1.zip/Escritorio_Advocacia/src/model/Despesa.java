package model;

import java.io.Serializable;
import java.util.Date;

public class Despesa implements Serializable {

	private static final long serialVersionUID = 3904985312831726862L;

	private final Date data;
	private final String descricao;
	private final double valor;

	public Despesa(Date data, String descricao, double valor) {
		this.data = data;
		this.descricao = descricao;
		this.valor = valor;
	}

	public Date getData() {
		return data;
	}

	public String getDescricao() {
		return descricao;
	}

	public double getValor() {
		return valor;
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append("Despesa: \n");
		sb.append("Data: ").append(this.getData()).append("\n");
		sb.append("Descrição: ").append(this.getDescricao()).append("\n");
		sb.append("Valor: R$").append(String.format("%.2f", this.getValor())).append("\n");
		return sb.toString();
	}

}
