package model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class Conta implements IConta, Serializable {

	private static final long serialVersionUID = -34890744951586545L;

	private List<Despesa> despesas = new ArrayList<>();
	private List<Pagamento> pagamentos = new ArrayList<>();

	@Override
	public void addPagamento(Date data, double valor, EFormaPagamento formaPagamento) {
		Pagamento pag = new Pagamento(data, valor, formaPagamento);
		this.pagamentos.add(pag);
	}

	@Override
	public void addDespesa(Date data, String descricao, double valor) {
		Despesa despesa = new Despesa(data, descricao, valor);
		this.despesas.add(despesa);
	}

	@Override
	public double getTotalPagamento() {
		double total_pagamentos = 0;
		for (Pagamento pagamento : pagamentos) {
			total_pagamentos += pagamento.getValor();
		}
		return total_pagamentos;
	}

	public double getTotalDespesas() {
		double total_despesas = 0;
		for (Despesa despesa : despesas) {
			total_despesas += despesa.getValor();
		}
		return total_despesas;
	}

	@Override
	public double getSaldoConta() {
		return getTotalPagamento() - getTotalDespesas();
	}

	@Override
	public StringBuilder getExtrato() {
		StringBuilder sb = new StringBuilder();

		sb.append("Extrato de Conta\n");
		sb.append("====================================\n");
		sb.append("Despesas:\n");

		for (Despesa despesa : despesas) {
			sb.append(String.format("Data: %s, Descrição: %s, Valor: %.2f\n", despesa.getData(), despesa.getDescricao(),
					despesa.getValor()));
		}

		sb.append("\nPagamentos:\n");

		for (Pagamento pagamento : pagamentos) {
			sb.append(String.format("Data: %s, Valor: %.2f, Forma de Pagamento: %s\n", pagamento.getData(),
					pagamento.getValor(), pagamento.getFormaPagamento().name()));
		}

		sb.append("\nSaldo Atual: ");
		sb.append(String.format("%.2f", this.getSaldoConta()));

		return sb;
	}

	// Método para obter a lista de despesas
	public List<Despesa> getDespesas() {
		return despesas;
	}

	// Método para obter a lista de pagamentos
	public List<Pagamento> getPagamentos() {
		return pagamentos;
	}

}
