package model;

public enum EFaseProcesso {
	INICIAL, INSTRUCAO, DECISAO, RECURSO, CONCLUSAO;
}
