package model;

import exceptions.CpfInvalidoException;
import exceptions.PessoaException;
import util.IsValidCPF;

public class PessoaFisica extends Pessoa {

	private static final long serialVersionUID = -3191158094435719085L;

	private final String cpf;

	public PessoaFisica(String nome, String cpf, String email, String telefone) throws PessoaException {
		super(nome, email, telefone);
		if (!IsValidCPF.isValid(cpf)) {
			throw new CpfInvalidoException();
		}
		this.cpf = cpf;
	}

	@Override
	public String getRegistroRF() {
		return cpf;
	}

	@Override
	public String getTipoPessoa() {
		return "Pessoa Física";
	}

	@Override
	public String toString() {
		// Cria um StringBuilder para construir a string de forma eficiente
		StringBuilder sb = new StringBuilder();

		// Adiciona informações específicas da PessoaFisica
		sb.append("Pessoa Física: \n");
		sb.append(super.toString()); // Adiciona informações da Pessoa base
		sb.append(String.format("CPF: %s\n", this.cpf)); // Adiciona o CPF

		// Retorna a string completa
		return sb.toString();
	}
}
