package model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class Processo implements Serializable {

	private static final long serialVersionUID = -86570298823884993L;

	private final long numero;
	private final Date dataAbertura;
	private Date dataConclusao;
	private EFaseProcesso fase;
	private final Pessoa parteContraria;
	private Cliente cliente;
	private Tribunal tribunal;
	private List<Audiencia> audiencias = new ArrayList<>();
	private final Conta conta;

	public Processo(long numero, Date dataAbertura, Pessoa parteContraria, Tribunal tribunal, Conta conta,
			Cliente cliente) {
		this.numero = numero;
		this.dataAbertura = dataAbertura;
		this.parteContraria = parteContraria;
		this.tribunal = tribunal;
		this.conta = conta;
		this.cliente = cliente;
	}

	public Date getDataAbertura() {
		return this.dataAbertura;
	}

	public Date getDataConclusao() {
		return this.dataConclusao;
	}

	public void setDataConclusao(Date dataConclusao) {
		this.dataConclusao = dataConclusao;
		return;
	}

	public EFaseProcesso getFase() {
		return this.fase;
	}

	public void setFase(EFaseProcesso fase) {
		this.fase = fase;
		return;
	}

	public Tribunal getTribunal() {
		return this.tribunal;
	}

	public void setTribunal(Tribunal tribunal) {
		this.tribunal = tribunal;
		return;
	}

	public void addAudiencia(Audiencia audiencia) {
		this.audiencias.add(audiencia);
	}

	public long getNumero() {
		return this.numero;
	}

	public Cliente getCliente() {
		return this.cliente;
	}

	public Pessoa getParteContraria() {
		return this.parteContraria;
	}

	public Conta getConta() {
		return this.conta;
	}

	// TODO: getTotalCustas
	public double getTotalCustas() {
		return 0;
	}

	public List<Audiencia> getAudiencias() {
		return this.audiencias; // Retorna a lista de audiências
	}

	public void setAudiencias(List<Audiencia> audiencias) {
		if (audiencias == null) {
			throw new IllegalArgumentException("A lista de audiências não pode ser nula.");
		}
		this.audiencias = new ArrayList<>(audiencias);
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append("\nProcesso\n----------\n");
		sb.append("Numero: ").append(this.numero).append("\n");
		sb.append("Data de Abertura: ").append(this.dataAbertura != null ? this.dataAbertura.toString() : "N/A")
				.append("\n");
		sb.append("Data de Conclusão: ").append(this.dataConclusao != null ? this.dataConclusao.toString() : "N/A")
				.append("\n");
		sb.append("Fase: ").append(this.fase != null ? this.fase.toString() : "N/A").append("\n");
		sb.append("Parte Contrária: ").append(this.parteContraria != null ? this.parteContraria.toString() : "N/A")
				.append("\n");
		sb.append("Cliente: ").append(this.cliente != null ? this.cliente.toString() : "N/A").append("\n");
		sb.append("Tribunal: ").append(this.tribunal != null ? this.tribunal.toString() : "N/A").append("\n");
		sb.append(this.getAudiencias().toString());

		return sb.toString();
	}
}
