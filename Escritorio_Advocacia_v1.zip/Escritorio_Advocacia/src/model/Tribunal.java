package model;

import java.io.Serializable;

import exceptions.TribunalException;

public class Tribunal implements Serializable {

    private static final long serialVersionUID = -7603739373889601275L;

    private final String sigla;
    private final String descricao;
    private final String secao;

	public Tribunal(String sigla, String descricao, String secao) throws TribunalException {
        validarDados(sigla, descricao, secao);
        this.sigla = sigla;
        this.descricao = descricao;
        this.secao = secao;
    }

    private void validarDados(String sigla, String descricao, String secao) throws TribunalException {
        if (sigla == null || sigla.isEmpty()) {
            throw new TribunalException("Sigla deve ser preenchida.");
        }
        if (descricao == null || descricao.isEmpty()) {
            throw new TribunalException("Descrição deve ser preenchida.");
        }
        if (secao == null || secao.isEmpty()) {
            throw new TribunalException("Seção deve ser preenchida.");
        }
    }

    public String getSigla() {
        return sigla;
    }

    public String getDescricao() {
        return descricao;
    }

    public String getSecao() {
        return secao;
    }

    @Override
    public String toString() {
        return String.format("Tribunal [sigla=%s, descricao=%s, secao=%s]",
                             (sigla != null ? sigla : "null"),
                             (descricao != null ? descricao : "null"),
                             (secao != null ? secao : "null"));
    }
}
