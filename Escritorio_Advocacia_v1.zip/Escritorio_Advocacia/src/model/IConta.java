package model;

import java.util.Date;

public interface IConta {
	public abstract void addPagamento(Date data, double valor, EFormaPagamento formaPagamento);

	public abstract void addDespesa(Date data, String descricao, double valor);

	public abstract double getTotalPagamento();

	public abstract double getSaldoConta();

	public abstract StringBuilder getExtrato();

}
