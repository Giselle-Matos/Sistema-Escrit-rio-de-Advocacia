package model;

import java.io.Serializable;
import java.util.Date;

public class Audiencia implements Serializable {

	private static final long serialVersionUID = -5462068088084966465L;

	private final Date data;
	private final String recomendacao;
	private final Processo processo;
	private final Advogado advogado;

	public Audiencia(Date data, String recomendacao, Processo processo, Advogado advogado) {
		this.data = data;
		this.recomendacao = recomendacao;
		this.processo = processo;
		this.advogado = advogado;
	}

	public Date getData() {
		return data;
	}

	public String getRecomendacao() {
		return recomendacao;
	}

	public Processo getProcesso() {
		return processo;
	}

	public Advogado getAdvogado() {
		return advogado;
	}

	@Override
	public String toString() {
		return String.format("Audiência [data=%s, recomendacao=%s, advogado=%s]", (data != null ? data : "null"),
				(recomendacao != null ? recomendacao : "null"), (advogado != null ? advogado : "null"));
	}

}
