package model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class Cliente implements Serializable {

	private static final long serialVersionUID = -8144271137153113559L;

	private Pessoa pessoa;
	private List<Processo> processos = new ArrayList<>();

	public Cliente(Pessoa pessoa) {
		this.pessoa = pessoa;
	}

	public Pessoa getPessoa() {
		return this.pessoa;
	}

	public void addProcesso(Processo processo) {
		this.processos.add(processo);
	}

	public List<Processo> getProcessos() {
		return processos;
	}

	public StringBuilder getExtrato() {
		return null;
	}

	public double getSaldoContas() {
		return 0;
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();

		// Adiciona informações da pessoa
		if (pessoa != null) {
			sb.append("Pessoa: ").append(pessoa.toString()).append("\n");
		} else {
			sb.append("Pessoa: null\n");
		}

		// Adiciona informações dos processos
		if (processos != null && !processos.isEmpty()) {
			sb.append("Processos:\n");
			for (Processo processo : processos) {
				sb.append(" - ").append(processo.toString()).append("\n");
			}
		} else {
			sb.append("Nenhum processo associado.\n");
		}

		return sb.toString();
	}

}
