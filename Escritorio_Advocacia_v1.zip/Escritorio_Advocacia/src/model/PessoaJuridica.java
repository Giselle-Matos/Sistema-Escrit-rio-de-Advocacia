package model;

import exceptions.CnpjInvalidoException;
import exceptions.NomeInvalidoException;
import exceptions.PessoaException;
import util.IsValidCNPJ;

public class PessoaJuridica extends Pessoa {

	private static final long serialVersionUID = -6497663352761870660L;

	private final String cnpj;
	private PessoaFisica preposto;

	public PessoaJuridica(String nome, String cnpj, PessoaFisica preposto, String email, String telefone)
			throws PessoaException {
		super(nome, email, telefone);
		validarNome(nome);
		validarCNPJ(cnpj);
		this.cnpj = cnpj;
		this.preposto = preposto;
	}

	public PessoaJuridica(String nome, String cnpj, PessoaFisica preposto, String email) throws PessoaException {
		this(nome, cnpj, preposto, email, null);
	}

	public PessoaJuridica(String nome, String cnpj, PessoaFisica preposto) throws PessoaException {
		this(nome, cnpj, preposto, null, null);
	}

	private void validarNome(String nome) throws NomeInvalidoException {
		if (nome == null || nome.trim().isEmpty()) {
			throw new NomeInvalidoException();
		}
	}

	private void validarCNPJ(String cnpj) throws CnpjInvalidoException {
		if (!IsValidCNPJ.isValid(cnpj)) {
			throw new CnpjInvalidoException();
		}
	}

	@Override
	public String getRegistroRF() {
		return cnpj;
	}

	public PessoaFisica getPreposto() {
		return this.preposto;
	}

	public void setPreposto(PessoaFisica preposto) {
		this.preposto = preposto;
	}

	@Override
	public String getTipoPessoa() {
		return "Pessoa Jurídica";
	}

	@Override
	public String toString() {
		// Cria um StringBuilder para construir a string de forma eficiente
		StringBuilder sb = new StringBuilder();

		// Adiciona informações específicas da PessoaJuridica
		sb.append("Pessoa Jurídica: \n");
		sb.append(super.toString()); // Adiciona informações da Pessoa base
		sb.append(String.format("CNPJ: %s\n", this.cnpj)); // Adiciona o CNPJ
		sb.append(String.format("Preposto: %s\n", this.preposto != null ? this.preposto.getNome() : "Nenhum")); // Adiciona
																												// o
																												// Preposto

		// Retorna a string completa
		return sb.toString();
	}
}
