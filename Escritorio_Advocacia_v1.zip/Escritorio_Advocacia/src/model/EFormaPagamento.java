package model;

public enum EFormaPagamento {
	PIX, DEBITO, CREDITO, DINHEIRO, CHEQUE;
}
