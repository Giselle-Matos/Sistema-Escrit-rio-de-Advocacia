package model;

import java.io.Serializable;
import java.util.Date;

public class Pagamento implements Serializable {

	private static final long serialVersionUID = 2604036908949046448L;

	private EFormaPagamento formaPagamento;
	private final Date data;
	private final double valor;

	public Pagamento(Date data, double valor, EFormaPagamento formaPagamento) {
		this.data = data;
		this.valor = valor;
		this.formaPagamento = formaPagamento;
	}

	public EFormaPagamento getFormaPagamento() {
		return formaPagamento;
	}

	public Date getData() {
		return data;
	}

	public double getValor() {
		return valor;
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append("Pagamento: \n");
		sb.append("Data: ").append(this.getData()).append("\n");
		sb.append("Valor: R$").append(String.format("%.2f", this.getValor())).append("\n");
		sb.append("Forma de Pagamento: ").append(this.getFormaPagamento()).append("\n");
		return sb.toString();
	}

}
