package model;

import exceptions.PessoaException;

public class Advogado extends PessoaFisica {

	private static final long serialVersionUID = -7170807890979505674L;

	private final String registro;

	// Construtor principal
	public Advogado(String nome, String cpf, String registro, String email, String telefone) throws PessoaException {
		super(nome, cpf, email, telefone);
		// validarRegistro(registro);
		this.registro = registro;
	}

	// Construtor com telefone vazio
	public Advogado(String nome, String cpf, String registro, String email) throws PessoaException {
		this(nome, cpf, registro, email, null);
	}

	// Construtor com email e telefone vazios
	public Advogado(String nome, String cpf, String registro) throws PessoaException {
		this(nome, cpf, registro, null, null);
	}

//	private void validarRegistro(String registro) throws RegistroInvalidoException {
//		if (registro == null || registro.trim().isEmpty()) {
//			throw new RegistroInvalidoException();
//		}
//	}

	public String getRegistro() {
		return this.registro;
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();

		sb.append("\nAdvogado: \n-------------");
		sb.append(super.toString());
		sb.append(String.format("\nRegistro: %s", this.registro));
		return sb.toString();
	}
}
